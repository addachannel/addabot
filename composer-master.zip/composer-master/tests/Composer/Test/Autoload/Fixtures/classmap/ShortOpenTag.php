<?

class ShortOpenTag {}

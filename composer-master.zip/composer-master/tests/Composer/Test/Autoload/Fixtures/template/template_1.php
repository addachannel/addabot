/*
 * class templateClass_1
 * interface templateInterface_1
 * trait temlpateTrait_1
 */
<?php echo $code;
